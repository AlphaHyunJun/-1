package com.example.dangsindaesin;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.*;
import com.google.firebase.database.*;
import java.util.*;

public class CommunityBoardActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    PostAdapter adapter;
    List<PostItem> postList = new ArrayList<>();
    String nickname;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_community_board);

        recyclerView = findViewById(R.id.communityRecyclerView);
        TextView nicknameText = findViewById(R.id.communityTopNickname);
        Button writeButton = findViewById(R.id.writeButton);

        nickname = getIntent().getStringExtra("nickname");
        nicknameText.setText("👤 " + nickname);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new PostAdapter(postList, nickname);
        recyclerView.setAdapter(adapter);

        writeButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, PostDetailActivity.class);
            intent.putExtra("nickname", nickname);
            startActivity(intent);
        });

        loadPosts();
    }

    private void loadPosts() {
        FirebaseDatabase.getInstance().getReference("posts")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot snapshot) {
                        postList.clear();
                        for (DataSnapshot snap : snapshot.getChildren()) {
                            PostItem post = snap.getValue(PostItem.class);
                            post.postId = snap.getKey();
                            postList.add(post);
                        }
                        adapter.notifyDataSetChanged();
                    }

                    @Override public void onCancelled(DatabaseError error) {}
                });
    }
}
