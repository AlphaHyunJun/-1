package com.example.dangsindaesin;

public class PostItem {
    public String postId;
    public String title;
    public String content;
    public String author;

    public PostItem() {}

    public PostItem(String postId, String title, String content, String author) {
        this.postId = postId;
        this.title = title;
        this.content = content;
        this.author = author;
    }
}
