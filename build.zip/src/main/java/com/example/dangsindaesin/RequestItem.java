package com.example.dangsindaesin;

public class RequestItem {
    public String key;
    public String title;
    public String content;
    public String requester;
    public String acceptedBy;

    public RequestItem() {}

    public RequestItem(String key, String title, String content, String requester, String acceptedBy) {
        this.key = key;
        this.title = title;
        this.content = content;
        this.requester = requester;
        this.acceptedBy = acceptedBy;
    }
}
