// ✅ CommunityActivity.java
package com.example.dangsindaesin;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.*;
import java.util.ArrayList;
import java.util.List;

public class CommunityActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    RequestAdapter adapter;
    List<RequestItem> requestList = new ArrayList<>();
    String nickname;
    TextView topNickname;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_community);

        nickname = getIntent().getStringExtra("nickname");

        topNickname = findViewById(R.id.topNickname);
        if (nickname != null) {
            topNickname.setText("닉네임: " + nickname);
        }

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new RequestAdapter(requestList, nickname, true);
        recyclerView.setAdapter(adapter);

        loadRequests();
    }

    private void loadRequests() {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("requests");
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                requestList.clear();
                for (DataSnapshot snap : snapshot.getChildren()) {
                    RequestItem item = snap.getValue(RequestItem.class);
                    item.key = snap.getKey();
                    if (item.acceptedBy == null || item.acceptedBy.isEmpty()) {
                        requestList.add(item);
                    }
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(CommunityActivity.this, "불러오기 실패", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
