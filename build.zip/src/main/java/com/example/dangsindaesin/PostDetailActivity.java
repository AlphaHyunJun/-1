package com.example.dangsindaesin;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.*;
import com.google.firebase.database.*;
import java.util.*;

public class PostDetailActivity extends AppCompatActivity {

    TextView detailTitle, detailContent, detailAuthor;
    EditText commentInput;
    Button commentButton, reportPostButton;
    RecyclerView commentRecyclerView;
    CommentAdapter adapter;
    List<CommentItem> commentList = new ArrayList<>();

    String postId, nickname;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_detail);

        detailTitle = findViewById(R.id.detailTitle);
        detailContent = findViewById(R.id.detailContent);
        detailAuthor = findViewById(R.id.detailAuthor);
        commentInput = findViewById(R.id.commentInput);
        commentButton = findViewById(R.id.commentButton);
        reportPostButton = findViewById(R.id.reportPostButton);
        commentRecyclerView = findViewById(R.id.commentRecyclerView);

        postId = getIntent().getStringExtra("postId");
        nickname = getIntent().getStringExtra("nickname");

        adapter = new CommentAdapter(commentList, postId);
        commentRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        commentRecyclerView.setAdapter(adapter);

        loadPost();
        loadComments();

        commentButton.setOnClickListener(v -> {
            String text = commentInput.getText().toString().trim();
            if (!text.isEmpty()) {
                DatabaseReference ref = FirebaseDatabase.getInstance().getReference("comments").child(postId);
                String key = ref.push().getKey();
                if (key != null) {
                    CommentItem item = new CommentItem(key, text, nickname);
                    ref.child(key).setValue(item);
                    commentInput.setText("");
                }
            }
        });

        reportPostButton.setOnClickListener(v -> {
            FirebaseDatabase.getInstance().getReference("reports/posts").child(postId).setValue(true);
            Toast.makeText(this, "게시글이 신고되었습니다", Toast.LENGTH_SHORT).show();
        });
    }

    private void loadPost() {
        FirebaseDatabase.getInstance().getReference("posts").child(postId)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot snapshot) {
                        detailTitle.setText(snapshot.child("title").getValue(String.class));
                        detailContent.setText(snapshot.child("content").getValue(String.class));
                        detailAuthor.setText("작성자: " + snapshot.child("author").getValue(String.class));
                    }

                    @Override public void onCancelled(DatabaseError error) {}
                });
    }

    private void loadComments() {
        FirebaseDatabase.getInstance().getReference("comments").child(postId)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot snapshot) {
                        commentList.clear();
                        for (DataSnapshot snap : snapshot.getChildren()) {
                            CommentItem item = snap.getValue(CommentItem.class);
                            if (item != null) commentList.add(item);
                        }
                        adapter.notifyDataSetChanged();
                    }

                    @Override public void onCancelled(DatabaseError error) {}
                });
    }
}
