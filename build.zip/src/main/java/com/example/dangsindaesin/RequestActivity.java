package com.example.dangsindaesin;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class RequestActivity extends AppCompatActivity {

    EditText titleInput, contentInput;
    Button submitRequestButton;
    TextView requestNickname;
    String nickname, userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_request);

        titleInput = findViewById(R.id.titleInput);
        contentInput = findViewById(R.id.contentInput);
        submitRequestButton = findViewById(R.id.submitRequestButton);
        requestNickname = findViewById(R.id.requestNickname);

        nickname = getIntent().getStringExtra("nickname");
        userId = getIntent().getStringExtra("userId");

        requestNickname.setText("👤 " + nickname);

        submitRequestButton.setOnClickListener(v -> {
            String title = titleInput.getText().toString().trim();
            String content = contentInput.getText().toString().trim();

            if (TextUtils.isEmpty(title) || TextUtils.isEmpty(content)) {
                Toast.makeText(this, "제목과 내용을 입력해주세요.", Toast.LENGTH_SHORT).show();
                return;
            }

            DatabaseReference ref = FirebaseDatabase.getInstance().getReference("requests");
            String key = ref.push().getKey();

            if (key != null) {
                ref.child(key).child("title").setValue(title);
                ref.child(key).child("content").setValue(content);
                ref.child(key).child("requester").setValue(nickname);
                ref.child(key).child("acceptedBy").setValue("");
                Toast.makeText(this, "요청이 등록되었습니다.", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "요청 저장 중 오류가 발생했습니다.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
