package com.example.dangsindaesin;

import android.os.Bundle;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.*;
import com.google.firebase.database.*;
import java.util.*;

public class RequestListActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    TextView listTopNickname;
    RequestAdapter adapter;
    List<RequestItem> requestList = new ArrayList<>();
    String nickname;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_request_list);

        recyclerView = findViewById(R.id.requestRecyclerView);
        listTopNickname = findViewById(R.id.listTopNickname);

        nickname = getIntent().getStringExtra("nickname");
        listTopNickname.setText("👤 " + nickname);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new RequestAdapter(requestList, nickname);
        recyclerView.setAdapter(adapter);

        loadRequests();
    }

    private void loadRequests() {
        FirebaseDatabase.getInstance().getReference("requests")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        requestList.clear();
                        for (DataSnapshot snap : snapshot.getChildren()) {
                            RequestItem item = snap.getValue(RequestItem.class);
                            if (item != null) {
                                item.key = snap.getKey();
                                if (item.acceptedBy == null || item.acceptedBy.isEmpty()) {
                                    requestList.add(item);
                                }
                            }
                        }
                        adapter.notifyDataSetChanged();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {}
                });
    }
}
