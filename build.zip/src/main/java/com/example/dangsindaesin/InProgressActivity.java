package com.example.dangsindaesin;

import android.os.Bundle;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.*;
import com.google.firebase.database.*;
import java.util.*;

public class InProgressActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    RequestAdapter adapter;
    List<RequestItem> progressList = new ArrayList<>();
    String nickname;
    TextView inProgressTopNickname;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_in_progress);

        recyclerView = findViewById(R.id.inProgressRecyclerView);
        inProgressTopNickname = findViewById(R.id.inProgressTopNickname);

        nickname = getIntent().getStringExtra("nickname");
        inProgressTopNickname.setText("👤 " + nickname);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new RequestAdapter(progressList, nickname);
        recyclerView.setAdapter(adapter);

        loadInProgressTasks();
    }

    private void loadInProgressTasks() {
        FirebaseDatabase.getInstance().getReference("requests")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        progressList.clear();
                        for (DataSnapshot snap : snapshot.getChildren()) {
                            RequestItem item = snap.getValue(RequestItem.class);
                            if (item != null && item.acceptedBy != null && !item.acceptedBy.isEmpty()) {
                                item.key = snap.getKey();
                                progressList.add(item);
                            }
                        }
                        adapter.notifyDataSetChanged();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {}
                });
    }
}
