package com.example.dangsindaesin;

import android.view.*;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.database.FirebaseDatabase;
import java.util.List;

public class RequestAdapter extends RecyclerView.Adapter<RequestAdapter.ViewHolder> {

    List<RequestItem> list;
    String nickname;

    public RequestAdapter(List<RequestItem> list, String nickname) {
        this.list = list;
        this.nickname = nickname;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_request, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int pos) {
        RequestItem item = list.get(pos);
        h.title.setText(item.title);
        h.content.setText(item.content);
        h.requester.setText("요청자: " + item.requester);
        h.acceptedBy.setText("수락자: " + (item.acceptedBy == null || item.acceptedBy.isEmpty() ? "없음" : item.acceptedBy));

        if (item.acceptedBy == null || item.acceptedBy.isEmpty()) {
            h.accept.setEnabled(true);
            h.accept.setOnClickListener(v -> {
                FirebaseDatabase.getInstance()
                        .getReference("requests")
                        .child(item.key)
                        .child("acceptedBy")
                        .setValue(nickname);
                h.accept.setEnabled(false);
                h.accept.setText("매칭됨");
            });
        } else {
            h.accept.setEnabled(false);
            h.accept.setText("매칭됨");
        }
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView title, content, requester, acceptedBy;
        Button accept;

        public ViewHolder(@NonNull View v) {
            super(v);
            title = v.findViewById(R.id.requestTitle);
            content = v.findViewById(R.id.requestContent);
            requester = v.findViewById(R.id.requesterName);
            acceptedBy = v.findViewById(R.id.acceptedByName);
            accept = v.findViewById(R.id.acceptButton);
        }
    }
}
