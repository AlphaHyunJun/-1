package com.example.dangsindaesin;

public class CommentItem {
    public String commentId;
    public String content;
    public String commenter;

    public CommentItem() {}

    public CommentItem(String commentId, String content, String commenter) {
        this.commentId = commentId;
        this.content = content;
        this.commenter = commenter;
    }
}
