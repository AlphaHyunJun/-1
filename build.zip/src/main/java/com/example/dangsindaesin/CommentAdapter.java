package com.example.dangsindaesin;

import android.view.*;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.database.FirebaseDatabase;
import java.util.List;

public class CommentAdapter extends RecyclerView.Adapter<CommentAdapter.ViewHolder> {

    List<CommentItem> list;
    String postId;

    public CommentAdapter(List<CommentItem> list, String postId) {
        this.list = list;
        this.postId = postId;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_comment, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int pos) {
        CommentItem item = list.get(pos);
        h.text.setText(item.content);
        h.writer.setText("작성자: " + item.commenter);

        h.report.setOnClickListener(v -> {
            FirebaseDatabase.getInstance().getReference("reports/comments").child(item.commentId).setValue(true);
            Toast.makeText(v.getContext(), "댓글이 신고되었습니다", Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView text, writer;
        Button report;

        public ViewHolder(@NonNull View v) {
            super(v);
            text = v.findViewById(R.id.commentText);
            writer = v.findViewById(R.id.commenterText);
            report = v.findViewById(R.id.reportComment);
        }
    }
}
