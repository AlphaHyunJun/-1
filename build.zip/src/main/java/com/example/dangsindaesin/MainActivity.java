package com.example.dangsindaesin;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    TextView nicknameText;
    Button requestButton, requestListButton, inProgressButton, communityButton;
    String nickname, userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nicknameText = findViewById(R.id.nicknameText);
        requestButton = findViewById(R.id.requestButton);
        requestListButton = findViewById(R.id.requestListButton);
        inProgressButton = findViewById(R.id.inProgressButton);
        communityButton = findViewById(R.id.communityButton);

        nickname = getIntent().getStringExtra("nickname");
        userId = getIntent().getStringExtra("userId");

        if (nickname != null) {
            nicknameText.setText("👤 " + nickname);
        }

        requestButton.setOnClickListener(v -> {
            Intent i = new Intent(MainActivity.this, RequestActivity.class);
            i.putExtra("nickname", nickname);
            i.putExtra("userId", userId);
            startActivity(i);
        });

        requestListButton.setOnClickListener(v -> {
            Intent i = new Intent(MainActivity.this, RequestListActivity.class);
            i.putExtra("nickname", nickname);
            i.putExtra("userId", userId);
            startActivity(i);
        });

        inProgressButton.setOnClickListener(v -> {
            Intent i = new Intent(MainActivity.this, InProgressActivity.class);
            i.putExtra("nickname", nickname);
            i.putExtra("userId", userId);
            startActivity(i);
        });

        communityButton.setOnClickListener(v -> {
            Intent i = new Intent(MainActivity.this, CommunityBoardActivity.class);
            i.putExtra("nickname", nickname);
            i.putExtra("userId", userId);
            startActivity(i);
        });
    }
}
